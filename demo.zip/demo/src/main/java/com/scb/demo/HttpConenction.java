package com.scb.demo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class HttpConenction {
	
 public ResponseEntity<String> getAccess() throws IOException  {
	RestTemplate restTemplate = new RestTemplate();
	String fooResourceUrl
	  = "http://localhost:8080/spring-rest/foos";
	String text
    = "Service Started";
	Path fileName = Path.of(
	         "C:/Users/Parthi/OneDrive/Desktop/Booze files/demo.txt");
	 try {
			Files.writeString(fileName, text);
			 String file_content = Files.readString(fileName);
			 System.out.println(file_content);
		} catch (IOException e) {
			Files.writeString(fileName, e.getMessage().toString());
			e.printStackTrace();
			
			
		}
	ResponseEntity<String> response
	  = restTemplate.getForEntity(fooResourceUrl + "/1", String.class);
	//Assertions.assertEquals(response.getStatusCode(), HttpStatus.OK);
	
return response;
}
}
