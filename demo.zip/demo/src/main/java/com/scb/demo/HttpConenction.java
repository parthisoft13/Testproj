package com.scb.demo;

import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class HttpConenction {
	
 public String getAccess() throws IOException  {
	 
	 Logger logger = Logger.getLogger("MyLog");  
	    FileHandler fh;  
	    {
	    try {  

	    
	        fh = new FileHandler("C:/Users/Parthi/OneDrive/Desktop/Booze files/MyLogFile.log");  
	        logger.addHandler(fh);
	        SimpleFormatter formatter = new SimpleFormatter();  
	        fh.setFormatter(formatter);  

	        // the following statement is used to log any messages  
	        logger.info("Service is started... ");  

	    } catch (SecurityException ex) {  
	        ex.printStackTrace();  
	    } catch (IOException e) {  
	        e.printStackTrace();  
	    } 
	 
	 
	   
	 RestTemplate restTemplate = new RestTemplate();

	 String url = "https://raw-tutorial.s3.eu-west-1.amazonaws.com/patients.json";
	 logger.info(url);  
	 Path path = Path.of("src/main/resources/application.json");
	 String fileString = Files.readString(path);
	 //String requestJson = ;
	 HttpHeaders headers = new HttpHeaders();
	 headers.setContentType(MediaType.APPLICATION_JSON);
	 logger.info(url);  
	 HttpEntity<String> entity = new HttpEntity<String>(fileString,headers);
	 String answer = restTemplate.postForObject(url, entity, String.class);
	 System.out.println(answer);
	 logger.info(answer);  
	 //Files.writeString(fileName, answer);
return answer;
}
 }
}
