package com.scb.demo;

import java.net.URI;

import org.springframework.util.Assert;

public class CounterPartyAutomation 
{
   
     
    
}