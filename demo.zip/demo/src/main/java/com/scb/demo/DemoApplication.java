package com.scb.demo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoApplication {

	@Value("${spring.datasource.url}")
	public static String url="url";
	public static void main(String[] args) throws IOException {
		SpringApplication.run(DemoApplication.class, args);
		
		 HttpConenction conn = new HttpConenction();
		 conn.getAccess();
		 
     

     
    

	}

}
